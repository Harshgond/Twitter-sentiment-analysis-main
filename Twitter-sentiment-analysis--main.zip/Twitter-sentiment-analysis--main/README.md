# Twitter-sentiment-analysis-
Here i collected data from twitter and applied many more supervised machine learning algorithms
